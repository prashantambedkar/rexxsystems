<html>
	<head>
		<style>
			.table2 {
 			 border: 1px solid black;
 			 border-collapse: collapse;
			}
		</style>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	</head>
	<body>
		<table>
			<tr>
				<td colspan="3">
					<h3>Search By :-</h3>
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" id="customername" name="customername" placeholder="Customer Name">
				</td>
				<td>
					<input type="text" id="productname" name="productname" placeholder="Product Name">
				</td>
				<td>
					<input type="text" id="price" name="price" placeholder="Price">
				</td>
			</tr>
		<table>
		<br>
		<table id="list-sales-items" class="table2">
			<!-- <tr class="table2">
				<td class="table2">
					<b>Sales Id</b>
				</td>
				<td class="table2">
					<b>Customer Name</b>
				</td>
				<td class="table2">
					<b>Customer Mail</b>
				</td>
				<td class="table2">
					<b>Product Id</b>
				</td>
				<td class="table2">
					<b>Product Name</b>
				</td>
				<td class="table2">
					<b>Product Price</b>
				</td>
				<td class="table2">
					<b>Sales Date & Time</b>
				</td>
			</tr> -->		

		</table>
	</body>
</html>
<script type="text/javascript">
var listObject=[];
$(document).ready(function(){
 	$.ajax({
	          dataType: "json",
	          type: "POST",
	          url: "http://localhost/rexx/api/fetch_data.php",                 
	          

	          success: function (response) {
	              console.log(response);
	              
	              if(response.status == 200){
	                 // location.reload();
	                  
	                 var jsonObj=response.data;
		            for (var i = 0; i < jsonObj.length; i++){
		              listObject.push(jsonObj[i]);
		            }
					//console.log('hiii');
		            loadsalesdata();
	                
	              }else{                 
	                  
	              } 
	          },
	          error: function (response) {
	            console.log(response);
	          }
	       });

 	$('#customername').keypress(function(e) {
 			
        if ( e.keyCode == 13 ) {  
            loadfilter();
        }
    });

    $('#productname').keypress(function(e) {
 		
        if ( e.keyCode == 13 ) {  
			loadfilter();
        }
    });

    $('#price').keypress(function(e) {
 		
        if ( e.keyCode == 13 ) {  
           loadfilter();
        }
    });
	
});
function loadsalesdata(){
	var html='<tr class="table2">'+
					'<td class="table2">'+
						'<b>Sales Id</b>'+
					'</td>'+
					'<td class="table2">'+
						'<b>Customer Name</b>'+
					'</td>'+
					'<td class="table2">'+
						'<b>Customer Mail</b>'+
					'</td>'+
					'<td class="table2">'+
						'<b>Product Id</b>'+
					'</td>'+
					'<td class="table2">'+
						'<b>Product Name</b>'+
					'</td>'+
					'<td class="table2">'+
						'<b>Product Price</b>'+
					'</td>'+
					'<td class="table2">'+
						'<b>Sales Date & Time</b>'+
					'</td>'+
				'</tr>';
			
	$.each(listObject, function(i, data) {
		   	html+='<tr class="table2">'+
					'<td class="table2">'+
						data.sales_id+
					'</td>'+
					'<td class="table2">'+
						data.customer_name+
					'</td>'+
					'<td class="table2">'+
						data.customer_email+
					'</td>'+
					'<td class="table2">'+
						data.product_id+
					'</td>'+
					'<td class="table2">'+
						data.product_name+
					'</td>'+
					'<td class="table2">'+
						data.product_price+
					'</td>'+
					'<td class="table2">'+
						data.salesdate+
					'</td>'+
				'</tr>';
	});
		$('#list-sales-items').html(html);
}

function loadfilter()
{
	listObject=[];	
	var customename=document.getElementById("customername").value;
    var producname=document.getElementById("productname").value;
    var pric=document.getElementById("price").value;
    $.ajax({
          dataType: "json",
          type: "GET",
          url: "http://localhost/rexx/api/filter_data.php",
          data: {"customername":customename,"productname":producname,"price":pric},                
          

          success: function (response) {
             // console.log(response);
              
              if(response.status == 200){
                 // location.reload();
                  
                 var jsonObj=response.data;
                for (var i = 0; i < jsonObj.length; i++){
                  listObject.push(jsonObj[i]);
                }

                 loadsalesdata();
                
              }else{                 
                  
              } 
          },
          error: function (response) {
            console.log(response);
          }
       });
}
</script>