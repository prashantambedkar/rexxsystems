<?php
	
#tables
define('TABLE_CUSTOMERS', 'customers');
define('TABLE_PRODUCTS', 'products');
define('TABLE_SALES', 'sales');

#Local db
define('DB_NAME', 'rexxsystems');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost' );

?>