<?php

require 'constants.php';

require 'dbconnection.php';


function fetchAllRows($result)
{
    $arr = [];
    while($data = mysqli_fetch_assoc($result)){
        $arr[] = $data;
    }
    return $arr;
}

function returnJson($data, $message, $status, $choosenElement=null)
{
	header('Access-Control-Allow-Origin: *');  
	header('Access-Control-Allow-Methods: GET, POST');
	header("Content-Type: application/json", true);
	echo json_encode(['data'=>$data,'message'=>$message, 'status'=>$status, 'extra'=>$choosenElement]);
}


?>