<?php
require 'common.php';

try {

	$sql = "
	    SELECT sa.id as sales_id,cus.name as customer_name,cus.email as customer_email,pd.id as product_id,pd.name as product_name,pd.price as product_price,sa.salesdate
		from `".TABLE_SALES."` as sa 
		INNER JOIN 
		`".TABLE_CUSTOMERS."` as cus 
		on cus.id=sa.customerid 
		INNER JOIN 
		`".TABLE_PRODUCTS."` as pd 
		on pd.id=sa.productid
		where 
		cus.name like '%".$_GET['customername']."%'
		and 
		pd.name like '%".$_GET['productname']."%'
		and 
		pd.price like '%".$_GET['price']."%'
		
	";
	$result = $conn->query($sql);
	$lists = fetchAllRows($result);
	$conn->close();
	returnJson($lists, "Successfully Fetched Sales Details!!", 200);
	die;
} catch(Exception $e) {
	returnJson(false, "Unexpected issue occured, Please tryagain", 500);
	die;
}

